# Homework- Splitting data and data leakage
## Setup
* Install python
`python 3.13.7`
## Prerequisite
* Must put `MNIST` folder in the same folder with `dataset_loader.py`
## Usage
* Run following code in the terminal
`python datasetloader.py`